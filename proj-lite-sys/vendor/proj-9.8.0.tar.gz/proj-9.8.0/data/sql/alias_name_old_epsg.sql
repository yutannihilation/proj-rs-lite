-- Edited manually
-- This file contains old aliases that got removed during EPSG updates
-- obtained doing:
-- git show ${SHA1}| grep alias_name | grep "\-INSERT" | sed "s/-INSERT/INSERT/" | sed "s/'EPSG')/'EPSG_OLD')/"

-- All aliases removed between EPSG v6.7 and v7.1
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6140','NAD83(CSRS98)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6312','HR1901','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6312','D48','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6123','Kartasto Koordinaati Järjestelmä 1966','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5136','Admiralty Datum','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6326','DGN-95','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6627','RGR92','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6638','St Pierre et Miquelon 1950','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5159','IGN89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','22780','Levant / Levant Stereographic','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31170','Zanderij / Surinam Old TM','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4134','PSD93','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5701','ODN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5702','NGVD29','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5703','NAVD88','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5709','NAP','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5711','AHD','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5712','AHD (Tasmania)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5713','CGVD28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5714','msl height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5715','msl depth','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5723','Japan Levelling Datum','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5724','PHD93','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5728','LN02','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5729','LHN95','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7405','GB National Grid + ODN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7407','NAD27 / TX_N + NGVD29','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20004','1995 Coord. Sys. zone 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20005','1995 Coord. Sys. zone 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20006','1995 Coord. Sys. zone 6','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20007','1995 Coord. Sys. zone 7','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20008','1995 Coord. Sys. zone 8','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20009','1995 Coord. Sys. zone 9','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20010','1995 Coord. Sys. zone 10','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20011','1995 Coord. Sys. zone 11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20012','1995 Coord. Sys. zone 12','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20013','1995 Coord. Sys. zone 13','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20014','1995 Coord. Sys. zone 14','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20015','1995 Coord. Sys. zone 15','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20016','1995 Coord. Sys. zone 16','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20017','1995 Coord. Sys. zone 17','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20018','1995 Coord. Sys. zone 18','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20019','1995 Coord. Sys. zone 19','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20020','1995 Coord. Sys. zone 20','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20021','1995 Coord. Sys. zone 21','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20022','1995 Coord. Sys. zone 22','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20023','1995 Coord. Sys. zone 23','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20024','1995 Coord. Sys. zone 24','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20025','1995 Coord. Sys. zone 25','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20026','1995 Coord. Sys. zone 26','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20027','1995 Coord. Sys. zone 27','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20028','1995 Coord. Sys. zone 28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20029','1995 Coord. Sys. zone 29','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20030','1995 Coord. Sys. zone 30','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20031','1995 Coord. Sys. zone 31','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20032','1995 Coord. Sys. zone 32','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20790','Lisbon / Portuguese National Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21413','Beijing / Gauss zone 13','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21414','Beijing / Gauss zone 14','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21415','Beijing / Gauss zone 15','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21416','Beijing / Gauss zone 16','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21417','Beijing / Gauss zone 17','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21418','Beijing / Gauss zone 18','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21419','Beijing / Gauss zone 19','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21420','Beijing / Gauss zone 20','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21421','Beijing / Gauss zone 21','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21422','Beijing / Gauss zone 22','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21423','Beijing / Gauss zone 23','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','27200','GD49 / NZ Map Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28402','1942 Coord. Sys. zone 2','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28403','1942 Coord. Sys. zone 3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28404','1942 Coord. Sys. zone 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28405','1942 Coord. Sys. zone 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28406','1942 Coord. Sys. zone 6','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28407','1942 Coord. Sys. zone 7','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28408','1942 Coord. Sys. zone 8','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28409','1942 Coord. Sys. zone 9','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28410','1942 Coord. Sys. zone 10','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28411','1942 Coord. Sys. zone 11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28412','1942 Coord. Sys. zone 12','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28413','1942 Coord. Sys. zone 13','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28414','1942 Coord. Sys. zone 14','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28415','1942 Coord. Sys. zone 15','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28416','1942 Coord. Sys. zone 16','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28417','1942 Coord. Sys. zone 17','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28418','1942 Coord. Sys. zone 18','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28419','1942 Coord. Sys. zone 19','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28420','1942 Coord. Sys. zone 20','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28421','1942 Coord. Sys. zone 21','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28422','1942 Coord. Sys. zone 22','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28423','1942 Coord. Sys. zone 23','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28424','1942 Coord. Sys. zone 24','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28425','1942 Coord. Sys. zone 25','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28426','1942 Coord. Sys. zone 26','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28427','1942 Coord. Sys. zone 27','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28428','1942 Coord. Sys. zone 28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28429','1942 Coord. Sys. zone 29','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28430','1942 Coord. Sys. zone 30','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28431','1942 Coord. Sys. zone 31','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','28432','1942 Coord. Sys. zone 32','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','30200','Trinidad 1903 / Trinidad','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','30491','Voirol /N Algerie ancien','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','30492','Voirol /S Algerie ancien','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31467','DHDN / 3-degree Gauss-Kruger zone 3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31468','DHDN / 3-degree Gauss-Kruger zone 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31469','DHDN / 3-degree Gauss-Kruger zone 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31466','DHDN / 3-degree Gauss-Kruger zone 2','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4312','HR1901','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4312','D48','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4805','HR1901 (Ferro)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4805','D48 (Ferro)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31467','PD/83 / Gauss-Kruger zone 3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31468','PD/83 / Gauss-Kruger zone 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31468','RD/83 / Gauss-Kruger zone 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31469','RD/83 / Gauss-Kruger zone 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31282','MGI / Austria Central','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31283','MGI / Austria East','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31281','MGI / Austria West','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4314','PD/83','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4314','RD/83','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','27562','NTF (Paris) / Centre France','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20791','Lisbon 1937 (Lisbon)/Portuguese Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5705','Kronstadt','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5736','Huang Hai 1956','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5738','HKPD','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5737','Huang Hai 1985','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2333','Xian 1980 / 6-degree Gauss-Kruger zone 23','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2045','Hanoi 1972 / 6-degree Gauss-Kruger zone 18','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2397','Pulkovo 1942(83) / 3-degree Gauss-Kruger zone 3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2398','Pulkovo 1942(83) / 3-degree Gauss-Kruger zone 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2399','Pulkovo 1942(83) / 3-degree Gauss-Kruger zone 3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2395','S Yemen / Gauss zone 8','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2396','S Yemen / Gauss zone 9','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2309','DGN-95 / TM 116 SE','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2310','DGN-95 / TM 132 SE','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32646','DGN-95 / UTM zone 46N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32647','DGN-95 / UTM zone 47N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32648','DGN-95 / UTM zone 48N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32649','DGN-95 / UTM zone 49N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32650','DGN-95 / UTM zone 50N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32651','DGN-95 / UTM zone 51N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32652','DGN-95 / UTM zone 52N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32747','DGN-95 / UTM zone 47S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32748','DGN-95 / UTM zone 48S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32749','DGN-95 / UTM zone 49S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32750','DGN-95 / UTM zone 50S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32751','DGN-95 / UTM zone 51S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32752','DGN-95 / UTM zone 52S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32753','DGN-95 / UTM zone 53S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32754','DGN-95 / UTM zone 54S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4326','DGN-95','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5732','Belfast Lough','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4638','St Pierre et Miquelon 1950','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4978','DGN-95','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4979','DGN-95','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4170','SIRGAS 1995','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4974','SIRGAS 1995','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','32000','SIRGAS 1995 / UTM zone 25S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31999','SIRGAS 1995 / UTM zone 24S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31998','SIRGAS 1995 / UTM zone 23S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31997','SIRGAS 1995 / UTM zone 22S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31996','SIRGAS 1995 / UTM zone 21S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31995','SIRGAS 1995 / UTM zone 20S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31994','SIRGAS 1995 / UTM zone 19S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31993','SIRGAS 1995 / UTM zone 18S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31992','SIRGAS 1995 / UTM zone 17S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31991','SIRGAS 1995 / UTM zone 22N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31990','SIRGAS 1995 / UTM zone 21N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31989','SIRGAS 1995 / UTM zone 20N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31988','SIRGAS 1995 / UTM zone 19N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31987','SIRGAS 1995 / UTM zone 18N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31986','SIRGAS 1995 / UTM zone 17N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4975','SIRGAS 1995','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5723','JSLD','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5787','Baltic 1980','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5782','REDNAP','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3089','NAD83 / Kentucky (ftUS)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3088','NAD83 / Kentucky','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3090','NAD83(HARN) / Kentucky','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3091','NAD83(HARN) / Kentucky (ftUS)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2866','NAD83(HPGN) / Puerto Rico & Virgin Is.','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3091','KY1Z','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2970','Sainte Anne / UTM zone 20N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2973','Fort Desaix / UTM zone 20N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5757','IGN 1988','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5758','IGN 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5793','IGN 1950','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5794','IGN 1955','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5795','IGN 1951','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3106','Gulshan 303 / Bangladesh TM','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5713','CVD28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5713','Canadian Vertical Datum of 1928','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5705','Baltic 1977','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5705','BHS77','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31469','DE_RD/83 / GK_3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31468','DE_RD/83 / GK_3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31468','DE_PD/83 / GK_3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31467','DE_PD/83 / GK_3','EPSG_OLD');

-- All aliases removed between EPSG v7.1 and v8.0
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6120','Old Greek','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5100','msl','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5119','NGF - IGN69','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5120','NGF - IGN78','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6818','Jednotné Trigonometrické Síte Katastrální (Ferro)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6156','Jednotné Trigonometrické Síte Katastrální','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1035','REGCAN95','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6152','NAD83 (HPGN)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2081','Chos Malal / Argentina 2','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2082','Pampa d Castillo / Arg 2','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2083','Hito XVIII / Argentina 2','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2096','Korean 1985 / East Belt','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2097','Korean 1985 / Cen. Belt','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2098','Korean 1985 / West Belt','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','21292','Barbados NationaI Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','24373','Kalianpur / India III','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','24374','Kalianpur / India IV','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','24381','Kalianpur 75 / India III','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','24383','Kalianpur 75 / India IV','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','29873','Timbalai  / Borneo (m)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4182','Observatorio Flores','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2188','Observatorio Flores / UTM zone 25N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4960','National Geodetic System [Argentina]','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4961','National Geodetic System [Argentina]','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2188','(PT_AZO_OCCI / UTM - see alias remarks)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4182','Observatorio 1966','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4182','Observatorio Meteorologico 1939','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2188','Observatorio Meteorologico 1939 / UTM zone 25N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3152','ST74 0 gon 65:-1','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3034','ETRF89 / ETRS-LCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3035','ETRF89 / ETRS-LAEA','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3038','ETRF89 / ETRS-TM26','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3039','ETRF89 / ETRS-TM27','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3040','ETRF89 / ETRS-TM28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3041','ETRF89 / ETRS-TM29','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3042','ETRF89 / ETRS-TM30','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3043','ETRF89 / ETRS-TM31','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3044','ETRF89 / ETRS-TM32','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3045','ETRF89 / ETRS-TM33','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3046','ETRF89 / ETRS-TM34','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3047','ETRF89 / ETRS-TM35','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3048','ETRF89 / ETRS-TM36','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3049','ETRF89 / ETRS-TM37','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3050','ETRF89 / ETRS-TM38','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3051','ETRF89 / ETRS-TM39','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3067','ETRF89 / ETRS-TM35FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4672','CI71','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2188','Azores Occ. 39 / UTM 25N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2333','Xian 1980 / G-K zone 19','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2365','Xian 1980 / 3GK zone 42','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3112','GDA94 / Geoscience LCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20791','Lisbon / Portuguese Grid','EPSG_OLD');

-- All aliases removed between EPSG v8.0 and v9.0
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5122','JSLD','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6143','Côte D''Ivoire (Ivory Coast)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6142','Côte D''Ivoire (Ivory Coast)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6141','New Israeli Datum','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6141','NID','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1042','RGNA 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1042','Red Geodesica Nacional 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2039','Israeli TM Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5702','National Geodetic Vertical Datum of 1929 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5703','North American Vertical Datum of 1988 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','22191','C Inchauspe /Argentina 1','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','22192','C Inchauspe /Argentina 2','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','22193','C Inchauspe /Argentina 3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','22194','C Inchauspe /Argentina 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','22195','C Inchauspe /Argentina 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','22196','C Inchauspe /Argentina 6','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','22197','C Inchauspe /Argentina 7','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','29872','Timbalai  / Borneo (ft)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4143','Côte D''Ivoire','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4142','Côte D''Ivoire','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2993','NAD83(HPGN) / Oregon Lambert','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2994','NAD83(HPGN) / Oregon Lambert (ft)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3091','NAD83(HARN) / KY1Z ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3425','NAD83(HPGN) / Iowa North (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3426','NAD83(HPGN) / Iowa South (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3427','NAD83(HPGN) / Kansas North (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3428','NAD83(HPGN) / Kansas South (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3429','NAD83(HPGN) / Nevada East (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3430','NAD83(HPGN) / Nevada Central (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3431','NAD83(HPGN) / Nevada West (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3432','NAD83(HPGN) / New Jersey (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2993','NAD83(HARN) / Oregon Lambert (m)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3040','ETRF89 / TM28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3041','ETRF89 / TM29','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3042','ETRF89 / TM30','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3043','ETRF89 / TM31','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3044','ETRF89 / TM32','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3045','ETRF89 / TM33','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3046','ETRF89 / TM34','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3047','ETRF89 / TM35','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3048','ETRF89 / TM36','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3049','ETRF89 / TM37','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3643','NAD83(NSRS2007) / Oregon Lambert (m)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3547','NAD83(NSRS) / KY1Z ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2315','Campo Inchauspe /UTM 19S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2316','Campo Inchauspe /UTM 20S','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2870','NAD83(HARN) / CA 1 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2871','NAD83(HARN) / CA 2 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2872','NAD83(HARN) / CA 3 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2873','NAD83(HARN) / CA 4 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2874','NAD83(HARN) / CA 5 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2875','NAD83(HARN) / CA 6 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2876','NAD83(HARN) / CO N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2877','NAD83(HARN) / CO C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2878','NAD83(HARN) / CO S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2881','NAD83(HARN) / FL E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2882','NAD83(HARN) / FL W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2883','NAD83(HARN) / FL N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2884','NAD83(HARN) / GA E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2885','NAD83(HARN) / GA W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2886','NAD83(HARN) / ID E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2887','NAD83(HARN) / ID C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2888','NAD83(HARN) / ID W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2967','NAD83(HARN) / IN E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2968','NAD83(HARN) / IN W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2891','NAD83(HARN) / KY N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2892','NAD83(HARN) / KY S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2894','NAD83(HARN) / MA md ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2895','NAD83(HARN) / MA Is ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2899','NAD83(HARN) / MS E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2900','NAD83(HARN) / MS W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2902','NAD83(HARN) / NM E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2903','NAD83(HARN) / NM C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2904','NAD83(HARN) / NM W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2905','NAD83(HARN) / NY E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2906','NAD83(HARN) / NY C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2907','NAD83(HARN) / NY W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2908','NAD83(HARN) / NY LI ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2911','NAD83(HARN) / OK N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2912','NAD83(HARN) / OK S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2916','NAD83(HARN) / TX N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2917','NAD83(HARN) / TX NC ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2918','NAD83(HARN) / TX C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2919','NAD83(HARN) / TX SC ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2920','NAD83(HARN) / TX S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2924','NAD83(HARN) / VA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2925','NAD83(HARN) / VA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2926','NAD83(HARN) / WA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2927','NAD83(HARN) / WA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2928','NAD83(HARN) / WI N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2929','NAD83(HARN) / WI C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2930','NAD83(HARN) / WI S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2992','NAD83 / Oregon LCC (ft)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2993','NAD83(HARN) / OR LCC m','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2994','NAD83(HARN) / OR LCC ft','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3441','NAD83(HARN) / AR N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3442','NAD83(HARN) / AR S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3760','NAD83(HARN) / HI 3 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3443','NAD83(HARN) / IL E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3444','NAD83(HARN) / IL W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3425','NAD83(HARN) / IA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3426','NAD83(HARN) / IA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3427','NAD83(HARN) / KS N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3428','NAD83(HARN) / KS S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3456','NAD83(HARN) / LA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3457','NAD83(HARN) / LA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26855','NAD83(HARN) / ME E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26856','NAD83(HARN) / ME W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26858','NAD83(HARN) / MN C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26857','NAD83(HARN) / MN N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26859','NAD83(HARN) / MN S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3430','NAD83(HARN) / NV C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3429','NAD83(HARN) / NV E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3431','NAD83(HARN) / NV W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3753','NAD83(HARN) / OH N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3754','NAD83(HARN) / OH S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3363','NAD83(HARN) / PA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3365','NAD83(HARN) / PA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3458','NAD83(HARN) / SD N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3459','NAD83(HARN) / SD S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3569','NAD83(HARN) / UT C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3568','NAD83(HARN) / UT N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3570','NAD83(HARN) / UT S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26861','NAD83(HARN) / WV N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26862','NAD83(HARN) / WV S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3755','NAD83(HARN) / WY E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3756','NAD83(HARN) / WY EC ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3758','NAD83(HARN) / WY W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3757','NAD83(HARN) / WY WC ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3417','NAD83 / Iowa N (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3418','NAD83 / Iowa S (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3419','NAD83 / Kansas N (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3420','NAD83 / Kansas S (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3421','NAD83 / Nevada E (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3422','NAD83 / Nevada C (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3423','NAD83 / Nevada W (ft US)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3424','NAD83 / New Jersey ft US','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3433','NAD83 / Arkansas N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3434','NAD83 / Arkansas S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3435','NAD83 / Illinois E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3436','NAD83 / Illinois W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3451','NAD83 / Louisiana N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3452','NAD83 / Louisiana S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3453','NAD83 / LA Offshore ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3455','NAD83 / S Dakota S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3560','NAD83 / Utah North ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3566','NAD83 / Utah Cen ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3567','NAD83 / Utah South ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3737','NAD83 / Wyoming EC ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3738','NAD83 / Wyoming WC ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26849','NAD83 / Minnesota N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26850','NAD83 / Minnesota C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26851','NAD83 / Minnesota S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3485','NAD83(NSRS) / AR N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3487','NAD83(NSRS) / AR S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3490','NAD83(NSRS) / CA 1 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3492','NAD83(NSRS) / CA 2 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3494','NAD83(NSRS) / CA 3 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3496','NAD83(NSRS) / CA 4 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3498','NAD83(NSRS) / CA 5 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3500','NAD83(NSRS) / CA 6 ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3502','NAD83(NSRS) / CO C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3504','NAD83(NSRS) / CO N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3506','NAD83(NSRS) / CO S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3512','NAD83(NSRS) / FL E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3515','NAD83(NSRS) / FL N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3517','NAD83(NSRS) / FL W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3519','NAD83(NSRS) / GA E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3521','NAD83(NSRS) / GA W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3537','NAD83(NSRS) / IA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3539','NAD83(NSRS) / IA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3523','NAD83(NSRS) / ID C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3525','NAD83(NSRS) / ID E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3527','NAD83(NSRS) / ID W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3529','NAD83(NSRS) / IL E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3531','NAD83(NSRS) / IL W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3533','NAD83(NSRS) / IN E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3535','NAD83(NSRS) / IN W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3541','NAD83(NSRS) / KS N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3543','NAD83(NSRS) / KS S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3545','NAD83(NSRS) / KY N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3549','NAD83(NSRS) / KY S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3551','NAD83(NSRS) / LA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3553','NAD83(NSRS) / LA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3584','NAD83(NSRS) / MA Is ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3586','NAD83(NSRS) / MA md ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26863','NAD83(NSRS) / ME E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26864','NAD83(NSRS) / ME W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26866','NAD83(NSRS) / MN C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26865','NAD83(NSRS) / MN N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26867','NAD83(NSRS) / MN S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3598','NAD83(NSRS) / MS E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3600','NAD83(NSRS) / MS W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3618','NAD83(NSRS) / NM C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3620','NAD83(NSRS) / NM E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3622','NAD83(NSRS) / NM W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3608','NAD83(NSRS) / NV C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3610','NAD83(NSRS) / NV E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3612','NAD83(NSRS) / NV W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3624','NAD83(NSRS) / NY C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3626','NAD83(NSRS) / NY E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3628','NAD83(NSRS) / NY LI ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3630','NAD83(NSRS) / NY W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3728','NAD83(NSRS) / OH N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3729','NAD83(NSRS) / OH S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3640','NAD83(NSRS) / OK N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3642','NAD83(NSRS) / OK S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3644','NAD83(NSRS) / OR GIC ft','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3643','NAD83(NSRS) / OR GIC (m)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3650','NAD83(NSRS) / PA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3652','NAD83(NSRS) / PA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3658','NAD83(NSRS) / SD N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3660','NAD83(NSRS) / SD S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3677','NAD83(NSRS) / UT C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3680','NAD83(NSRS) / UT N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3683','NAD83(NSRS) / UT S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3686','NAD83(NSRS) / VA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3688','NAD83(NSRS) / VA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3690','NAD83(NSRS) / WA N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3692','NAD83(NSRS) / WA S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3696','NAD83(NSRS) / WI C ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3698','NAD83(NSRS) / WI N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3700','NAD83(NSRS) / WI S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26869','NAD83(NSRS) / WV N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','26870','NAD83(NSRS) / WV S ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3730','NAD83(NSRS) / WY E ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3731','NAD83(NSRS) / WY EC ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3733','NAD83(NSRS) / WY W ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3732','NAD83(NSRS) / WY WC ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4457','NAD83 / S Dakota N ftUS','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3112','GDA94 / GALCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4481','Red Geodesica Nacional 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4481','RGNA 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4482','Red Geodesica Nacional 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4482','RGNA 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4483','Red Geodesica Nacional 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4483','RGNA 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4484','RGNA 1993 / UTM zone 11N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4485','RGNA 1993 / UTM zone 12N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4486','RGNA 1993 / UTM zone 13N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4487','RGNA 1993 / UTM zone 14N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4489','RGNA 1993 / UTM zone 16N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3034','ETRS89 / ETRS-LCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3035','ETRS89 / ETRS-LAEA','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3042','ETRS89 / ETRS-TM30','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3067','ETRS89 / ETRS-TM35FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4484','Mexico 1993 / UTM 11N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4484','Red Geodesica Nacional 1993 / UTM 11N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4485','Mexico 1993 / UTM 12N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4485','Red Geodesica Nacional 1993 / UTM 12N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4486','Mexico 1993 / UTM 13N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4486','Red Geodesica Nacional 1993 / UTM 13N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4487','Mexico 1993 / UTM 14N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4487','Red Geodesica Nacional 1993 / UTM 14N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4488','Mexico 1993 / UTM 15N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4488','Red Geodesica Nacional 1993 / UTM 15N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4488','RGNA 1993 / UTM zone 15N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4489','Red Geodesica Nacional 1993 / UTM 16N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4489','Mexico 1993 / UTM 16N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5566','Ukraine 2000 / 6-degree Gauss-Kruger CM 21E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5566','Ukraine 2000 / 6GK 21E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5567','Ukraine 2000 / 6-degree Gauss-Kruger CM 27E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5567','Ukraine 2000 / 6GK 27E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5568','Ukraine 2000 / 6-degree Gauss-Kruger CM 33E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5568','Ukraine 2000 / 6GK 33E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5569','Ukraine 2000 / 6-degree Gauss-Kruger CM 39E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5569','Ukraine 2000 / 6GK 39E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5583','Ukraine 2000 / 3GK 39E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5582','Ukraine 2000 / 3GK 36E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5581','Ukraine 2000 / 3GK 33E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5580','Ukraine 2000 / 3GK 30E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5578','Ukraine 2000 / 3GK 24E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5579','Ukraine 2000 / 3GK 27E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','5561','UCS-2000','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5570','Ukraine 2000 / 3GK zn 7','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5571','Ukraine 2000 / 3GK zn 8','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5572','Ukraine 2000 / 3GK zn 9','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5573','Ukraine 2000 / 3GK zn 10','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5574','Ukraine 2000 / 3GK zn 11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5575','Ukraine 2000 / 3GK zn 12','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5576','Ukraine 2000 / 3GK zn 13','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5562','Ukraine 2000 / 6-degree Gauss-Kruger zone 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5563','Ukraine 2000 / 6-degree Gauss-Kruger zone 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5564','Ukraine 2000 / 6-degree Gauss-Kruger zone 6','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5565','Ukraine 2000 / 6-degree Gauss-Kruger zone 7','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5577','Ukraine 2000 / 3GK 21E','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4647','ETRS89 / UTM zone N32','EPSG_OLD');

-- All aliases removed between EPSG v9.0 and v9.1
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6258','ETRF89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6258','European Terrestrial Reference Frame 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4258','ETRF89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4258','EUREF89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4936','ETRF89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4936','EUREF89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4937','ETRF89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4937','EUREF89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','7624','WISCRS Pepin (ftUS)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','7624','WISCRS Pierce (ftUS)','EPSG_OLD');

-- All aliases removed between EPSG v9.1 and v9.4
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1161','Deutsches Haupthöhennetz 1912','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6143','Côte d''Ivoire (Ivory Coast)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6142','Côte d''Ivoire (Ivory Coast)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6171','Réseau Géodésique Français 1993','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6172','Posiciones Geodésicas Argentinas','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6190','Posiciones Geodésicas Argentinas 1998','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6123','Kartastokoordinaattijärjestelmä (1966)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6694','Posiciones Geodésicas Argentinas 1994','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1107','Cais da Figueirinha - Angra do Heroísmo','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6818','Systém Jednotnej trigonometrickej siete katastrálnej (Ferro)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1170','Deutsches Haupthöhennetz 2016','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1190','Landshæðarkerfi Islands 2004','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6156','Systém Jednotnej trigonometrickej siete katastrálnej','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1201','Systém Jednotnej trigonometrickej siete katastrálnej [JTSK03]','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1052','Systém Jednotné trigonometrické síte katastrální/05','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1055','Systém Jednotné trigonometrické síte katastrální/05 (Ferro)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1069','Red Geodésica Básica Nacional de El Salvador','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1067','Sistema Geodésico Nacional','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1062','Posiciones Geodésicas Argentinas 2007','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1072','Panamá-Colón 1911','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5182','Deutsches Haupthöhennetz 1985','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5181','Deutsches Haupthöhennetz 1992','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7407','NAD27 / TX_N + NGVD29 ht','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4143','Côte d''Ivoire','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4142','Côte d''Ivoire','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2040','Côte d''Ivoire / UTM zone 30N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2041','Côte d''Ivoire / UTM zone 30N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2042','Côte d''Ivoire / UTM zone 29N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2043','Côte d''Ivoire / UTM zone 29N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','6184','Cais da Figueirinha - Angra do Heroísmo height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5195','Hr_TRIE / NOH','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','5341','Marco de Referencia Geodésico Nacional Oficial','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','5342','Marco de Referencia Geodésico Nacional Oficial','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','5340','Marco de Referencia Geodésico Nacional Oficial','EPSG_OLD');

-- All aliases removed between EPSG v9.4 and v9.5
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3794','D96 / TM','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3912','D48 / GK','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6316','Macedonia State Coordinate System','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6637','GGN93 / Guam Map Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6637','Guam Geodetic Network 1993 / Guam Map Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6637','NAD83 / Guam Map Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6637','NAD83(MA11) / Guam Map Grid','EPSG_OLD');

-- All aliases removed between EPSG v9.5 and v9.7
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1141','ITRF2008 (2005.0)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1191','ITRF2014 (2010.0)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','7908','IGS97','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','7909','IGS00','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','7909','IGb00','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','7910','IGS05','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','7911','IGS08','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','7911','IGb08','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','5332','IGS08','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','5332','IGb08','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4896','IGS2005','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4919','IGS00','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4919','IGb00','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4918','IGS97','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','7789','IGS14','EPSG_OLD');

-- All aliases removed between EPSG v9.7 and v9.8.2
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6269','NAD83 (1986)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4269','NAD83 (1986)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','6642','Virgin Island Vertical Datum of 2009 height (m)','EPSG_OLD');

-- All aliases removed between EPSG v9.8.2 and v9.8.7
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1127','CGVD2013','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','6647','335','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','6647','CGVD2013(CGG2013a) - OHt','EPSG_OLD');

-- Changed in EPSG v9.8.9
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25828','ETRF89 / UTM zone 28N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25829','ETRF89 / UTM zone 29N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25830','ETRF89 / UTM zone 30N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25831','ETRF89 / UTM zone 31N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25832','ETRF89 / UTM zone 32N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25833','ETRF89 / UTM zone 33N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25834','ETRF89 / UTM zone 34N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25835','ETRF89 / UTM zone 35N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25836','ETRF89 / UTM zone 36N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25837','ETRF89 / UTM zone 37N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25884','ETRF89 / TM Baltic93','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2180','EUREF89 / CS92','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2196','EUREF89 / Kp2000 Jutland','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2197','EUREF89 / Kp2000 Zealand','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2198','EUREF89 / Kp2000 Bornholm','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3109','ETRF89 / Jersey Transverse Mercator','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3109','ETRF89 / JTM','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3108','ETRF89 / Guernsey Grid','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7416','EUREF89 / UTM zone 32N + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7417','EUREF89 / UTM zone 33N + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7418','EUREF89 / Kp2000 Jutland + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7419','EUREF89 / Kp2000 Zealand + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7420','EUREF89 / Kp2000 Bornholm + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3416','ETRF89 / Austria Lambert','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2176','ETRF89 / Poland CS2000 zone 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2177','ETRF89 / Poland CS2000 zone 6','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2178','ETRF89 / Poland CS2000 zone 7','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2179','ETRF89 / Poland CS2000 zone 8','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2180','ETRF89 / Poland CS92','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2196','ETRF89 / Kp2000 Jutland','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2197','ETRF89 / Kp2000 Zealand','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2198','ETRF89 / Kp2000 Bornholm','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2213','ETRF89 / TM 30 NE','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3034','ETRF89 / LCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3035','ETRF89 / LAEA','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3040','ETRF89 / UTM zone 28N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3041','ETRF89 / UTM zone 29N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3042','ETRF89 / UTM zone 30N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3043','ETRF89 / UTM zone 31N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3044','ETRF89 / UTM zone 32N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3045','ETRF89 / UTM zone 33N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3046','ETRF89 / UTM zone 34N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3047','ETRF89 / UTM zone 35N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3048','ETRF89 / UTM zone 36N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3049','ETRF89 / UTM zone 37N (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3067','ETRF89 / TM35FIN(E,N)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3126','ETRF89 / ETRS-GK19FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3127','ETRF89 / ETRS-GK20FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3128','ETRF89 / ETRS-GK21FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3129','ETRF89 / ETRS-GK22FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3130','ETRF89 / ETRS-GK23FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3131','ETRF89 / ETRS-GK24FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3132','ETRF89 / ETRS-GK25FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3133','ETRF89 / ETRS-GK26FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3134','ETRF89 / ETRS-GK27FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3135','ETRF89 / ETRS-GK28FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3136','ETRF89 / ETRS-GK29FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3137','ETRF89 / ETRS-GK30FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3138','ETRF89 / ETRS-GK31FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3145','ETRF89 / Faroe Lambert','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3447','ETRF89 / Belgian Lambert 2005','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7409','ETRF89 + EVRF2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7416','ETRF89 / UTM zone 32N + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7417','ETRF89 / UTM zone 33N + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7418','ETRF89 / Kp2000 Jutland + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7419','ETRF89 / Kp2000 Zealand + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7420','ETRF89 / Kp2000 Bornholm + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3763','ETRF89 / Portugal TM06','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3812','ETRF89 / Belgian Lambert 2008','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7423','ETRF89 + EVRF2007 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4093','ETRF89 / DKTM1','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4093','EUREF89 / DKTM1','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4094','ETRF89 / DKTM2','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4094','EUREF89 / DKTM2','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4095','ETRF89 / DKTM3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4095','EUREF89 / DKTM3','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4096','ETRF89 / DKTM4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4096','EUREF89 / DKTM4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','4099','ETRF89 / DKTM3 + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','4099','EUREF89 / DKTM3 + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','4097','ETRF89 / DKTM1 + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','4097','EUREF89 / DKTM1 + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','4098','ETRF89 / DKTM2 + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','4098','EUREF89 / DKTM2 + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','4100','ETRF89 / DKTM4 + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','4100','EUREF89 / DKTM4 + DVR90 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7405','OSGB36 / British National Grid + ODN height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3873','ETRF89 / GK19FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3874','ETRF89 / GK20FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3875','ETRF89 / GK21FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3876','ETRF89 / GK22FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3877','ETRF89 / GK23FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3878','ETRF89 / GK24FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3879','ETRF89 / GK25FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3880','ETRF89 / GK26FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3881','ETRF89 / GK27FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3882','ETRF89 / GK28FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3883','ETRF89 / GK29FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3884','ETRF89 / GK30FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3885','ETRF89 / GK31FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5048','ETRF89 / TM35FIN(N,E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5120','ETRF89 / NTM zone 20','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5120','EUREF89 / NTM zone 20','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5123','ETRF89 / NTM zone 23','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5123','EUREF89 / NTM zone 23','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5124','ETRF89 / NTM zone 24','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5124','EUREF89 / NTM zone 24','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5125','ETRF89 / NTM zone 25','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5125','EUREF89 / NTM zone 25','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5126','ETRF89 / NTM zone 26','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5126','EUREF89 / NTM zone 26','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5129','ETRF89 / NTM zone 29','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5129','EUREF89 / NTM zone 29','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5130','ETRF89 / NTM zone 30','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5130','EUREF89 / NTM zone 30','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5105','ETRF89 / NTM zone 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5105','EUREF89 / NTM zone 5','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5106','ETRF89 / NTM zone 6','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5106','EUREF89 / NTM zone 6','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5107','ETRF89 / NTM zone 7','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5107','EUREF89 / NTM zone 7','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5108','ETRF89 / NTM zone 8','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5108','EUREF89 / NTM zone 8','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5109','ETRF89 / NTM zone 9','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5109','EUREF89 / NTM zone 9','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5110','ETRF89 / NTM zone 10','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5110','EUREF89 / NTM zone 10','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5111','ETRF89 / NTM zone 11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5111','EUREF89 / NTM zone 11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5112','ETRF89 / NTM zone 12','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5112','EUREF89 / NTM zone 12','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5113','ETRF89 / NTM zone 13','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5113','EUREF89 / NTM zone 13','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5114','ETRF89 / NTM zone 14','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5114','EUREF89 / NTM zone 14','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5115','ETRF89 / NTM zone 15','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5115','EUREF89 / NTM zone 15','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5116','ETRF89 / NTM zone 16','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5116','EUREF89 / NTM zone 16','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5117','ETRF89 / NTM zone 17','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5117','EUREF89 / NTM zone 17','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5118','ETRF89 / NTM zone 18','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5118','EUREF89 / NTM zone 18','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5119','ETRF89 / NTM zone 19','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5119','EUREF89 / NTM zone 19','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5121','ETRF89 / NTM zone 21','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5121','EUREF89 / NTM zone 21','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5122','ETRF89 / NTM zone 22','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5122','EUREF89 / NTM zone 22','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5127','ETRF89 / NTM zone 27','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5127','EUREF89 / NTM zone 27','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5128','ETRF89 / NTM zone 28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5128','EUREF89 / NTM zone 28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4647','ETRF89 / UTM zone 32N (zE-N)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5649','ETRF89 / UTM zone 31N (zE-N)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5651','ETRF89 / UTM zone 31N (N-zE)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5652','ETRF89 / UTM zone 32N (N-zE)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5650','ETRF89 / UTM zone 33N (zE-N)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5653','ETRF89 / UTM zone 33N (N-zE)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','4839','ETRF89 / LCC Germany (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5945','ETRF89 / NTM zone 5 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5945','EUREF89 / NTM zone 5 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5946','ETRF89 / NTM zone 6 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5946','EUREF89 / NTM zone 6 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5947','ETRF89 / NTM zone 7 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5947','EUREF89 / NTM zone 7 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5949','ETRF89 / NTM zone 9 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5949','EUREF89 / NTM zone 9 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5950','ETRF89 / NTM zone 10 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5950','EUREF89 / NTM zone 10 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5951','ETRF89 / NTM zone 11 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5951','EUREF89 / NTM zone 11 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5952','ETRF89 / NTM zone 12 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5952','EUREF89 / NTM zone 12 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5953','ETRF89 / NTM zone 13 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5953','EUREF89 / NTM zone 13 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5954','ETRF89 / NTM zone 14 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5954','EUREF89 / NTM zone 14 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5955','ETRF89 / NTM zone 15 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5955','EUREF89 / NTM zone 15 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5956','ETRF89 / NTM zone 16 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5956','EUREF89 / NTM zone 16 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5957','ETRF89 / NTM zone 17 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5957','EUREF89 / NTM zone 17 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5958','ETRF89 / NTM zone 18 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5958','EUREF89 / NTM zone 18 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5959','ETRF89 / NTM zone 19 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5959','EUREF89 / NTM zone 19 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5960','ETRF89 / NTM zone 20 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5960','EUREF89 / NTM zone 20 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5961','ETRF89 / NTM zone 21 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5961','EUREF89 / NTM zone 21 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5962','ETRF89 / NTM zone 22 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5962','EUREF89 / NTM zone 22 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5963','ETRF89 / NTM zone 23 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5963','EUREF89 / NTM zone 23 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5964','ETRF89 / NTM zone 24 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5964','EUREF89 / NTM zone 24 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5965','ETRF89 / NTM zone 25 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5965','EUREF89 / NTM zone 25 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5967','ETRF89 / NTM zone 27 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5967','EUREF89 / NTM zone 27 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5966','ETRF89 / NTM zone 26 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5966','EUREF89 / NTM zone 26 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5968','ETRF89 / NTM zone 28 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5968','EUREF89 / NTM zone 28 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5969','ETRF89 / NTM zone 29 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5969','EUREF89 / NTM zone 29 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5970','ETRF89 / NTM zone 30 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5970','EUREF89 / NTM zone 30 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5973','ETRF89 / UTM zone 33 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5973','EUREF89 / UTM zone 33 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5975','ETRF89 / UTM zone 35 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5975','EUREF89 / UTM zone 35 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5974','ETRF89 / UTM zone 34 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5974','EUREF89 / UTM zone 34 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5976','ETRF89 / UTM zone 36 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5976','EUREF89 / UTM zone 36 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5972','ETRF89 / UTM zone 32 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5972','EUREF89 / UTM zone 32 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5971','ETRF89 / UTM zone 31 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5971','EUREF89 / UTM zone 31 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6070','EUREF89 / EPSG Arctic zone 3-11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6070','ETRF89 / EPSG Arctic zone 3-11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6071','EUREF89 / EPSG Arctic zone 4-26','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6071','ETRF89 / EPSG Arctic zone 4-26','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6073','EUREF89 / EPSG Arctic zone 5-11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6073','ETRF89 / EPSG Arctic zone 5-11','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6074','EUREF89 / EPSG Arctic zone 5-13','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6074','ETRF89 / EPSG Arctic zone 5-13','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6069','EUREF89 / EPSG Arctic zone 2-22','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6069','ETRF89 / EPSG Arctic zone 2-22','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5948','ETRF89 / NTM zone 8 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5948','EUREF89 / NTM zone 8 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6125','ETRF89 / EPSG Arctic zone 5-47','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6125','EUREF89 / EPSG Arctic zone 5-47','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6072','EUREF89 / EPSG Arctic zone 4-28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6072','ETRF89 / EPSG Arctic zone 4-28','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5942','ETRF89 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5942','EUREF89 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6147','ETRF89 / NTM zone 7 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6147','EUREF89 / NTM zone 7 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6148','ETRF89 / NTM zone 8 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6148','EUREF89 / NTM zone 8 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6149','ETRF89 / NTM zone 9 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6149','EUREF89 / NTM zone 9 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6146','ETRF89 / NTM zone 6 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6146','EUREF89 / NTM zone 6 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6145','ETRF89 / NTM zone 5 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6145','EUREF89 / NTM zone 5 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6170','ETRF89 / NTM zone 30 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6170','EUREF89 / NTM zone 30 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6169','ETRF89 / NTM zone 29 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6169','EUREF89 / NTM zone 29 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6168','ETRF89 / NTM zone 28 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6168','EUREF89 / NTM zone 28 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6167','ETRF89 / NTM zone 27 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6167','EUREF89 / NTM zone 27 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6166','ETRF89 / NTM zone 26 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6166','EUREF89 / NTM zone 26 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6165','ETRF89 / NTM zone 25 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6165','EUREF89 / NTM zone 25 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6164','ETRF89 / NTM zone 24 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6164','EUREF89 / NTM zone 24 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6163','ETRF89 / NTM zone 23 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6163','EUREF89 / NTM zone 23 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6162','ETRF89 / NTM zone 22 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6162','EUREF89 / NTM zone 22 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6161','ETRF89 / NTM zone 21 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6161','EUREF89 / NTM zone 21 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6160','ETRF89 / NTM zone 20 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6160','EUREF89 / NTM zone 20 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6159','ETRF89 / NTM zone 19 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6159','EUREF89 / NTM zone 19 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6158','ETRF89 / NTM zone 18 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6158','EUREF89 / NTM zone 18 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6157','ETRF89 / NTM zone 17 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6157','EUREF89 / NTM zone 17 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6156','ETRF89 / NTM zone 16 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6156','EUREF89 / NTM zone 16 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6155','ETRF89 / NTM zone 15 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6155','EUREF89 / NTM zone 15 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6154','ETRF89 / NTM zone 14 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6154','EUREF89 / NTM zone 14 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6153','ETRF89 / NTM zone 13 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6153','EUREF89 / NTM zone 13 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6152','ETRF89 / NTM zone 12 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6152','EUREF89 / NTM zone 12 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6151','ETRF89 / NTM zone 11 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6151','EUREF89 / NTM zone 11 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6150','ETRF89 / NTM zone 10 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6150','EUREF89 / NTM zone 10 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6171','ETRF89 / UTM zone 31 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6171','EUREF89 / UTM zone 31 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6172','ETRF89 / UTM zone 32 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6172','EUREF89 / UTM zone 32 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6173','ETRF89 / UTM zone 33 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6173','EUREF89 / UTM zone 33 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6174','ETRF89 / UTM zone 34 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6174','EUREF89 / UTM zone 34 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6175','ETRF89 / UTM zone 35 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6175','EUREF89 / UTM zone 35 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6176','ETRF89 / UTM zone 36 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6176','EUREF89 / UTM zone 36 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6144','ETRF89 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6144','EUREF89 + NN54 height','EPSG_OLD');

-- Changed in EPSG v9.8.11
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1178','EUREF89','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5318','ETRF89 / Faroe TM + FVR09 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5316','ETRF89 / Faroe TM','EPSG_OLD');

-- Changed in EPSG v9.8.15
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6728','Pico de las Nieves','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2062','Madrid (Madrid) / Spain','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4728','Pico de las Nieves','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4728','PN84','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','7799','Coordinate System 2005 zone 35','EPSG_OLD');

-- Changed in EPSG v9.9
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4289','Stelsel van de Rijksdriehoeksmeting','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4289','RD-Bessel','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5872','Highest Astronomic Tide height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5861','Lowest Astronomic Tide depth','EPSG_OLD');

-- Changed in EPSG v10.003
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2062','Madrid (Madrid) / Spain LCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2062','Madrid - LCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4479','CGCS 2000 - XYZ','EPSG_OLD');

-- Changed in EPSG v10.007
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5711','Australian Height Datum height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','9380','725','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','9380','IGb14 - LatLon','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5711','AHD71 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5711','AHD-TAS83 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5711','339','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5711','AHD - NOHt','EPSG_OLD');

-- Changed in EPSG v10.008
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6670','IGM95','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5215','EVRF2007','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1274','EVRF2019','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1287','EVRF2019mean','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','29873','Timbalai / Borneo (m)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6875','RDN2008 / Fuso Italia (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6876','RDN2008 / Fuso 12 (N-E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','29873','BT68 / RSO Borneo (m)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','29873','Timbalai 1968 / RSO Borneo (m)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','9389','EVRF2019_AMST / NH','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','9390','EVRF2019mean_AMST / NH','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6707','RDN2008 / TM32','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6708','RDN2008 / TM33','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6709','RDN2008 / TM34','EPSG_OLD');

-- Changed in EPSG v10.011
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3106','Gulshan  / Bangladesh TM','EPSG_OLD');

-- Changed in EPSG v10.017
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2176','System 2000/15','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2177','System 2000/18','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2178','System 2000/21','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2179','System 2000/24','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2180','System 1992','EPSG_OLD');

-- Changed in EPSG v10.027
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6215','Belge 1950','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6313','Belge 1972','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4215','BD 50','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4313','BD 72','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4809','BD 50 (Brussels)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31370','BD 72 / Lambert 72','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','31370','BD 72 / LB72','EPSG_OLD');

-- Changed in EPSG v10.033
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6151','CHTRF95','EPSG_OLD');

-- Changed in EPSG v10.035
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6171','RGF93','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4171','RGF93 (lat-lon)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4965','RGF93 (lat-lon)','EPSG_OLD');

-- Changed in EPSG v10.044
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','4181','LUREF','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2169','LUREF / Gauss','EPSG_OLD');

-- Changed in EPSG v10.054
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','9869','ETRS89 / MHR21 SnakeGrid','EPSG_OLD');

-- Changed in EPSG v10.063
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','8082','NAD83(CSRS)v6 / MTM NS zone 4','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','8083','NAD83(CSRS)v6 / MTM NS zone 5','EPSG_OLD');

-- Changed in EPSG v10.066
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1256','CGVD2013 (CGG2013a)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1127','CGVD2013 (CGG2013)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','9245','Canadian Geodetic Vertical Datum of 2013 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','9245','335','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','9245','CGVD2013(CGG2013a) - OHt','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','6647','Canadian Geodetic Vertical Datum of 2013 height','EPSG_OLD');

-- Changed in EPSG v10.074
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1253','SIRGAS-Chile 2016','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1294','INAGEOID2020','EPSG_OLD');

-- Changed in EPSG v10.077
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1199','Greenland  Vertical Reference 2000','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5714','mean sea level height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5715','mean sea level depth','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','29871','Timbalai  / Borneo (ch)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3106','Gulshan 303  / Bangladesh UTM','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3102','American Samoa 62 /  LCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20135','Blue Nile 1958  / UTM zone 35N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20136','Blue Nile 1958  / UTM zone 36N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20137','Blue Nile 1958  / UTM zone 37N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','20138','Blue Nile 1958  / UTM zone 38N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','8050','mean sea level height (ft)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','8050','msl height (ft)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','8051','mean sea level depth (ft)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','8051','msl depth (ft)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','8052','mean sea level height (ftUS)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','8052','msl height (ftUS)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','8053','mean sea level depth (ftUS)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','8053','msl depth (ftUS)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5715','msl depth','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','5714','msl height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3106','Gulshan 303  / Bangladesh Transverse Mercator','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3106','Gulshan 303  / BUTM','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','9678','Gulshan  / Bangladesh TM','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6893','WGS 84 / World Mercator +  EGM2008 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7955','St. Helena Tritan / UTM zone 30S +  Tritan 2011 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','7956','SHMG2015 +  SHVD2015 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','9755','798 WGS 84 (G2139) - LatLon ','EPSG_OLD');

-- Changed in EPSG v10.081
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','9069','ETRF2014- LatLon','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','9390','EVRF2019mean-NHt','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','9389','EVRF2019-NHt','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_crs','EPSG','9245','CGVD2013(CGG2013a) - OHt','EPSG_OLD');

-- Changed in EPSG v10.083
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6661','LKS92','EPSG');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3059','LKS92','EPSG');

-- Changed in EPSG v10.085
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3163','RGNC / Lambert New Caledonia','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3163','RGNC / LCC New Caledonia','EPSG_OLD');

-- Changed in EPSG v10.093
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5181','Korea 2000 / Central','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5182','Korea 2000 / Jeju','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5184','Korea 2000 / East Sea','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5185','Korea 2000 / West 2010','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5186','Korea 2000 / Central 2010','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5187','Korea 2000 / East 2010','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5188','Korea 2000 / E Sea 2010','EPSG_OLD');

-- Changed in EPSG v11.001
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','5206','DVR90','EPSG_OLD');

-- Changed in EPSG v11.008
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3844','S-42 / Stereo 70','EPSG_OLD');

-- Changed in EPSG v11.017
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5683','DB_REF / 3GK zone 3 E-N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5682','DB_REF / 3GK zone 2 E-N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5684','DB_REF / 3GK zone 4 E-N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5685','DB_REF / 3GK zone 5 E-N','EPSG_OLD');

-- Changed in EPSG v11.024
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','2393','YKG','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3067','ETRS89 / TM35FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3067','ETRS89-TM35FIN(E,N)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3067','ETRS-TM35FIN(E,N)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3873','ETRS89-GK19FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3874','ETRS89-GK20FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3875','ETRS89-GK21FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3876','ETRS89-GK22FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3877','ETRS89-GK23FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3878','ETRS89-GK24FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3879','ETRS89-GK25FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3880','ETRS89-GK26FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3881','ETRS89-GK27FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3882','ETRS89-GK28FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3883','ETRS89-GK29FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3884','ETRS89-GK30FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3885','ETRS-GK31FIN','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','3903','ETRS89-TM35FIN(N,E)/N2000','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5048','ETRS89-TM35FIN(N,E)','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','3902','ETRS89-TM35FIN(N,E)/N60','EPSG_OLD');
-- EUREF-FIN
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1391','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','10688','ETRS89','EPSG_OLD'); -- ETRS89-FIN [EUREF-FIN] (geocentric)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','10689','ETRS89','EPSG_OLD'); -- ETRS89-FIN [EUREF-FIN] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','10690','ETRS89','EPSG_OLD'); -- ETRS89-FIN [EUREF-FIN] (2d)

-- Changed in EPSG v12.007
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','25884','LKS92 / TM Baltic93','EPSG_OLD');

-- Changed in EPSG v12.021
-- ETRS89-NOR [EUREF89]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1407','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','10875','ETRS89','EPSG_OLD'); -- ETRS89-NOR [EUREF89] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','10874','ETRS89','EPSG_OLD'); -- ETRS89-NOR [EUREF89] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','10873','ETRS89','EPSG_OLD'); -- ETRS89-NOR [EUREF89] (geocentric)

-- Changed in EPSG v12.027
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5973','ETRS89 / UTM zone 33 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5975','ETRS89 / UTM zone 35 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5974','ETRS89 / UTM zone 34 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5976','ETRS89 / UTM zone 36 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5972','ETRS89 / UTM zone 32 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5971','ETRS89 / UTM zone 31 + NN2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6171','ETRS89 / UTM zone 31 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6172','ETRS89 / UTM zone 32 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6173','ETRS89 / UTM zone 33 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6174','ETRS89 / UTM zone 34 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6175','ETRS89 / UTM zone 35 + NN54 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','6176','ETRS89 / UTM zone 36 + NN54 height','EPSG_OLD');

-- Changed in EPSG v12.033
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3447','ETRS89 / Lambert 2005','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6962','ETRS89 / Albania LCC','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','6870','ETRS89 / Albania TM','EPSG_OLD');
-- OSNet v2009
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1425','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11009','ETRS89','EPSG_OLD'); -- ETRS89-GBR [OSNet v2009] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11008','ETRS89','EPSG_OLD'); -- ETRS89-GBR [OSNet v2009] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11007','ETRS89','EPSG_OLD'); -- ETRS89-GBR [OSNet v2009] (geocentric)
-- Albanian Geodetic Reference Frame 2010
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1429','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11047','ETRS89','EPSG_OLD'); -- ETRS89-ALB [KRGJSH 2010] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11046','ETRS89','EPSG_OLD'); -- ETRS89-ALB [KRGJSH 2010] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11045','ETRS89','EPSG_OLD'); -- ETRS89-ALB [KRGJSH 2010] (geocentric)
-- ETRS89-AUT [2002]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1431','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11057','ETRS89','EPSG_OLD'); -- ETRS89-AUT [2002] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11056','ETRS89','EPSG_OLD'); -- ETRS89-AUT [2002] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11055','ETRS89','EPSG_OLD'); -- ETRS89-AUT [2002] (geocentric)
-- Belgian Reference Frame 2002
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1432','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11063','ETRS89','EPSG_OLD'); -- ETRS89-BEL [BEREF2002] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11062','ETRS89','EPSG_OLD'); -- ETRS89-BEL [BEREF2002] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11061','ETRS89','EPSG_OLD'); -- ETRS89-BEL [BEREF2002] (geocentric)
-- ETRS89-PRT [1995]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1439','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11108','ETRS89','EPSG_OLD'); -- ETRS89-PRT [1995] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11107','ETRS89','EPSG_OLD'); -- ETRS89-PRT [1995] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11106','ETRS89','EPSG_OLD'); -- ETRS89-PRT [1995] (geocentric)
-- Belgian Reference Frame 2011
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1447','European Terrestrial Reference System 1989','EPSG_OLD');


-- Changed in EPSG v12.035
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','10826','ETRS89 + LAS-2000 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','10839','ETRS89 + LAS-2000 height','EPSG_OLD');
-- ETRS89-ESP [REGENTE]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1441','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11134','ETRS89','EPSG_OLD'); -- ETRS89-ESP [REGENTE] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11130','ETRS89','EPSG_OLD'); -- ETRS89-ESP [REGENTE] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11129','ETRS89','EPSG_OLD'); -- ETRS89-ESP [REGENTE] (geocentric)

-- Changed in EPSG v12.037
-- Rete Dinamica Nazionale 2008
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1132','RDN2008','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1132','European Terrestrial Reference System 1989','EPSG_OLD');
-- Istituto Geografico Militaire 1995
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6670','IGM95','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3065','ETRF89 IT / UTM zone 33N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3064','ETRF89 IT / UTM zone 32N','EPSG_OLD');
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','9716','ETRF89 IT / UTM zone 34N','EPSG_OLD');

-- Changed in EPSG v12.038
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','3067','EUREF-FIN / UTM zone 35N','EPSG_OLD');

-- Changed in EPSG v12.039
INSERT INTO "alias_name" VALUES('projected_crs','EPSG','5316','ETRS89 / FOTM','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5698','RGF93 / Lambert-93 + NGF-IGN69 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','5699','RGF93 / Lambert-93 + NGF-IGN78 height','EPSG_OLD');
INSERT INTO "alias_name" VALUES('compound_crs','EPSG','10659','ETRS89 + EOMA 1980 height','EPSG_OLD');
-- ETRS89-FRO [2008]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1436','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11087','ETRS89','EPSG_OLD'); -- ETRS89-FRO [2008] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11086','ETRS89','EPSG_OLD'); -- ETRS89-FRO [2008] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11085','ETRS89','EPSG_OLD'); -- ETRS89-FRO [2008] (geocentric)
-- ETRS89-HUN [ETRF2000]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1444','European Terrestrial Reference Frame 2000','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11163','ETRF2000','EPSG_OLD'); -- ETRS89-HUN [ETRF2000] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11162','ETRF2000','EPSG_OLD'); -- ETRS89-HUN [ETRF2000] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11161','ETRF2000','EPSG_OLD'); -- ETRS89-HUN [ETRF2000] (geocentric)

-- Changed in EPSG v12.041
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1297','EVRF2007-PL','EPSG_OLD');
-- ETRF2000 Poland
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1305','ETRF2000-PL','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','9702','ETRF2000-PL','EPSG_OLD'); -- ETRS89-POL [PL-ETRF2000] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','9701','ETRF2000-PL','EPSG_OLD'); -- ETRS89-POL [PL-ETRF2000] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','9700','ETRF2000-PL','EPSG_OLD'); -- ETRS89-POL [PL-ETRF2000] (geocentric)

-- Changed in EPSG v12.042
-- Serbian Reference Network 1998
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1034','SREF98','EPSG_OLD');
-- Serbian Spatial Reference System 2000
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1214','STRS00','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1214','SRB_ETRS89','EPSG_OLD');
-- ETRS89/DREF91 Realization 2016
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1353','ETRS89/DREF91/2016','EPSG_OLD');
-- ETRS89-IRE [ETRF2000]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','6173','European Terrestrial Reference System 1989','EPSG_OLD');

-- Changed in EPSG v12.043
-- ETRS89-CZE [2007]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1433','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11070','ETRS89','EPSG_OLD'); -- ETRS89-CZE [2007] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11069','ETRS89','EPSG_OLD'); -- ETRS89-CZE [2007] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11068','ETRS89','EPSG_OLD'); -- ETRS89-CZE [2007] (geocentric)
-- ETRS89-SVK [SKTRF09]
INSERT INTO "alias_name" VALUES('geodetic_datum','EPSG','1434','European Terrestrial Reference System 1989','EPSG_OLD');
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11076','ETRS89','EPSG_OLD'); -- ETRS89-SVK [2007] (2d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11075','ETRS89','EPSG_OLD'); -- ETRS89-SVK [2007] (3d)
INSERT INTO "alias_name" VALUES('geodetic_crs','EPSG','11074','ETRS89','EPSG_OLD'); -- ETRS89-SVK [2007] (geocentric)

-- Changed in EPSG v12.047
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1270','MSL NL','EPSG_OLD');
INSERT INTO "alias_name" VALUES('vertical_datum','EPSG','1290','LAT NL','EPSG_OLD');
